CREATE PROCEDURE [dbo].[AddDataModelDataSource]
    @ItemID uniqueidentifier,
    @DSType int = 0,
    @DSKind int = 0,
    @AuthType int = 0,
    @ConnectionString varbinary(max) = null,
    @Username varbinary(max) = null,
    @Password varbinary(max) = null
AS
BEGIN
INSERT
    INTO DataModelDataSource
        ([ItemID],
        [DSType],
        [DSKind],
        [AuthType],
        [ConnectionString],
        [Username],
        [Password])
    VALUES
        (@ItemID,
        @DSType,
        @DSKind,
        @AuthType,
        @ConnectionString,
        @Username,
        @Password)
END
go

