CREATE PROCEDURE [dbo].GetCatalogItemContent
@CatalogItemID AS uniqueidentifier
AS

SELECT
    [Content]
FROM
    [Catalog]
WHERE
    [ItemID] = @CatalogItemID
go

